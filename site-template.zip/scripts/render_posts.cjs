const fs = require('node:fs');
const vm = require('node:vm');

const files = process.argv.slice(2);
const context = vm.createContext({ console });
context.window = context;
for (const file of files) {
  vm.runInContext(fs.readFileSync(file, 'utf8'), context, { filename: file });
}

async function main() {
  const { markdown, inline, code = [] } = JSON.parse(fs.readFileSync(0, 'utf8'));
  const renderer = context.createBlogMarkdownRenderer();
  const sources = markdown.map((path) => fs.readFileSync(path, 'utf8'));
  const moduleUrl = (source) =>
    `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
  const { loadHighlighter, normalizeLanguage } = await import(
    moduleUrl(fs.readFileSync(require.resolve('../js/blog-highlight.js'), 'utf8'))
  );
  const languages = sources.flatMap((source) =>
    renderer.parse(source, {}).filter((token) => token.type === 'fence')
      .map((token) => token.info.trim().split(/\s+/)[0])
  );
  const highlighter = await loadHighlighter(
    [...languages, ...code.map((block) => block.language)],
    async (url) => {
      const response = await fetch(url, { signal: AbortSignal.timeout(30000) });
      if (!response.ok) throw new Error(`Failed to load ${url}: ${response.status}`);
      return import(moduleUrl(await response.text()));
    }
  );
  function highlight(source, name) {
    const language = normalizeLanguage(name);
    return language ? highlighter.highlight(source, { language, ignoreIllegals: true }).value : null;
  }
  renderer.set({
    highlight(source, name) {
      const value = highlight(source, name);
      return value === null ? '' :
        `<pre><code class="hljs language-${normalizeLanguage(name)}" data-highlighted="yes">${value}</code></pre>`;
    },
  });
  process.stdout.write(JSON.stringify({
    markdown: sources.map((source) => renderer.render(source)),
    inline: inline.map((tex) => context.katex.renderToString(tex)),
    code: code.map((block) => highlight(block.code, block.language)),
  }));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
