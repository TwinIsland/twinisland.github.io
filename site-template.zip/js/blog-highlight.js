const assetRoot =
  'https://cdn.jsdelivr.net/npm/@highlightjs/cdn-assets@11.12.0/es/';
const languages = {
  bash: ['sh', 'zsh'],
  cpp: ['c', 'cc', 'c++', 'h', 'hpp'],
  csharp: ['cs', 'c#'],
  css: [],
  diff: [],
  glsl: [],
  go: ['golang'],
  java: [],
  javascript: ['js', 'jsx', 'mjs', 'cjs'],
  json: [],
  markdown: ['md'],
  python: ['py'],
  rust: ['rs'],
  sql: [],
  typescript: ['ts', 'tsx'],
  xml: ['html', 'htm', 'svg'],
  yaml: ['yml'],
};
const aliases = new Map(
  Object.entries(languages).flatMap(([name, aliases]) =>
    [name, ...aliases].map((alias) => [alias, name])
  )
);
const dependencies = {
  javascript: ['xml'],
  typescript: ['xml'],
  markdown: ['xml'],
};
let core;
const grammars = new Map();

export function normalizeLanguage(language) {
  return aliases.get(String(language || '').toLowerCase()) || null;
}

export async function loadHighlighter(
  requested,
  importModule = (url) => import(url)
) {
  const names = [...new Set(requested.map(normalizeLanguage).filter(Boolean))];
  if (!names.length) return null;

  core ??= importModule(`${assetRoot}core.min.js`)
    .then((module) => module.default)
    .catch((error) => {
      core = null;
      throw error;
    });
  const highlighter = await core;
  async function loadLanguage(name) {
    if (!grammars.has(name)) {
      const loading = (async () => {
        await Promise.all((dependencies[name] || []).map(loadLanguage));
        const module = await importModule(
          `${assetRoot}languages/${name}.min.js`
        );
        highlighter.registerLanguage(name, module.default);
      })().catch((error) => {
        grammars.delete(name);
        throw error;
      });
      grammars.set(name, loading);
    }
    await grammars.get(name);
  }
  await Promise.all(names.map(loadLanguage));
  return highlighter;
}

export async function highlightCodeBlocks(root) {
  const blocks = [...root.querySelectorAll('pre code')].flatMap((code) => {
    const classes = `${code.className} ${code.parentElement.className}`;
    if (
      code.hasAttribute('data-highlighted') ||
      /(?:^|\s)(?:hljs|nohighlight|no-highlight)(?:\s|$)/i.test(classes) ||
      [...code.childNodes].some((node) => node.nodeType !== 3)
    ) {
      return [];
    }
    const language = normalizeLanguage(
      classes.match(/(?:^|\s)lang(?:uage)?-(\S+)/i)?.[1]
    );
    return language ? [{ code, language }] : [];
  });
  const highlighter = await loadHighlighter(
    blocks.map(({ language }) => language)
  );
  for (const { code, language } of blocks) {
    if (!code.isConnected) continue;
    code.innerHTML = highlighter.highlight(code.textContent, {
      language,
      ignoreIllegals: true,
    }).value;
    code.classList.add('hljs');
    code.dataset.highlighted = 'yes';
  }
}
